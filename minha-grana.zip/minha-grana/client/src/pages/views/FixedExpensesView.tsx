import React, { useState, useEffect } from "react";
import { useFixedExpenses, useCreateFixedExpense, useDeleteFixedExpense, useUpdateFixedExpense } from "@/hooks/use-financial";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2, Receipt, Pencil } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertFixedExpenseSchema } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { z } from "zod";

const formSchema = insertFixedExpenseSchema.extend({
  amount: z.coerce.string().refine((val) => !isNaN(Number(val)) && Number(val) > 0, "Valor inválido"),
});

export function FixedExpensesView() {
  const { data: expenses = [], isLoading } = useFixedExpenses();
  const createMutation = useCreateFixedExpense();
  const updateMutation = useUpdateFixedExpense();
  const deleteMutation = useDeleteFixedExpense();
  const [editingId, setEditingId] = useState<number | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      amount: "",
    },
  });

  useEffect(() => {
    if (editingId) {
      const expense = expenses.find(e => e.id === editingId);
      if (expense) {
        form.reset({
          name: expense.name,
          amount: String(expense.amount),
        });
      }
    } else {
      form.reset({
        name: "",
        amount: "",
      });
    }
  }, [editingId, expenses, form]);

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    if (editingId) {
      updateMutation.mutate({ id: editingId, ...data }, {
        onSuccess: () => {
          setEditingId(null);
          form.reset();
        },
      });
    } else {
      createMutation.mutate(data, {
        onSuccess: () => form.reset(),
      });
    }
  };

  const totalFixed = expenses.reduce((sum, item) => sum + Number(item.amount), 0);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Left Col: List */}
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-border p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Receipt className="w-5 h-5 text-primary" /> Gastos Fixos
              </h2>
              <p className="text-sm text-muted-foreground">Recorrentes todos os meses</p>
            </div>
            <div className="text-right">
              <span className="text-xs text-muted-foreground uppercase tracking-wider font-bold">Total Mensal</span>
              <div className="text-2xl font-bold text-rose-600">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalFixed)}
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {expenses.map((expense) => (
              <div 
                key={expense.id} 
                className="group flex items-center justify-between p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-transparent hover:border-slate-200 dark:hover:border-slate-700 transition-all"
              >
                <div className="font-medium text-slate-700 dark:text-slate-200">{expense.name}</div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 dark:text-white mr-2">
                    R$ {Number(expense.amount).toFixed(2)}
                  </span>
                  <button 
                    onClick={() => setEditingId(expense.id)}
                    className="opacity-0 group-hover:opacity-100 p-2 text-muted-foreground hover:text-primary hover:bg-primary/10 rounded-full transition-all"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => deleteMutation.mutate(expense.id)}
                    className="opacity-0 group-hover:opacity-100 p-2 text-muted-foreground hover:text-rose-500 hover:bg-rose-50 rounded-full transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}

            {expenses.length === 0 && (
              <div className="text-center py-10 text-muted-foreground">
                Nenhum gasto fixo cadastrado.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Right Col: Add Form */}
      <div>
        <div className="bg-primary/5 border border-primary/20 rounded-2xl p-6 sticky top-24">
          <h3 className="font-semibold text-primary mb-4">
            {editingId ? "Editar Gasto" : "Adicionar Novo"}
          </h3>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input placeholder="Nome (ex: Aluguel)" className="bg-white dark:bg-slate-900" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input type="number" placeholder="Valor (R$)" className="bg-white dark:bg-slate-900" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex gap-2">
                <Button type="submit" className="flex-1 bg-primary hover:bg-primary/90 text-white font-semibold shadow-lg shadow-primary/20" disabled={createMutation.isPending || updateMutation.isPending}>
                  {editingId 
                    ? (updateMutation.isPending ? "Salvando..." : "Salvar Alterações")
                    : (createMutation.isPending ? "Adicionando..." : "Adicionar Gasto")
                  }
                </Button>
                {editingId && (
                  <Button type="button" variant="outline" onClick={() => setEditingId(null)}>
                    Cancelar
                  </Button>
                )}
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
