import React, { useEffect, useState } from "react";
import { useIncomes, useCreateIncome, useUpdateIncome } from "@/hooks/use-financial";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2 } from "lucide-react";
import { clsx } from "clsx";

const MONTHS = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

export function IncomesView() {
  const { data: incomes = [], isLoading } = useIncomes();
  const createIncome = useCreateIncome();
  const updateIncome = useUpdateIncome();

  // We need to ensure all months exist in the DB or at least are displayed
  // This state will track edits before they are saved (onBlur)
  const [localData, setLocalData] = useState<Record<string, Record<string, string>>>({});

  // Initialize missing months on load
  useEffect(() => {
    if (!isLoading && incomes) {
      MONTHS.forEach(month => {
        const exists = incomes.find(i => i.month === month);
        if (!exists && !createIncome.isPending) {
           createIncome.mutate({
             month, 
             clt: "0", 
             app: "0", 
             ifood: "246", // Default per requirements
             auxilio: "120" // Default per requirements
            });
        }
      });
    }
  }, [incomes, isLoading, createIncome]);

  const handleInputChange = (id: number, field: string, value: string) => {
    setLocalData(prev => ({
      ...prev,
      [id]: {
        ...(prev[id] || {}),
        [field]: value
      }
    }));
  };

  const handleBlur = (id: number, field: string, originalValue: string) => {
    const newValue = localData[id]?.[field];
    if (newValue !== undefined && newValue !== String(originalValue)) {
      updateIncome.mutate({ id, [field]: newValue });
    }
  };

  if (isLoading) {
    return <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }

  // Sort by month index
  const sortedIncomes = [...incomes].sort((a, b) => {
    return MONTHS.indexOf(a.month) - MONTHS.indexOf(b.month);
  });

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-border overflow-hidden shadow-sm">
      <div className="p-6 border-b border-border bg-slate-50/50 dark:bg-slate-800/50">
        <h2 className="text-lg font-semibold">Registro de Receitas</h2>
        <p className="text-sm text-muted-foreground">Edite os valores diretamente na tabela. O total é calculado automaticamente.</p>
      </div>
      
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-800/50">
              <TableHead className="w-[100px]">Mês</TableHead>
              <TableHead>CLT</TableHead>
              <TableHead>App</TableHead>
              <TableHead>iFood</TableHead>
              <TableHead>Auxílio</TableHead>
              <TableHead className="text-right font-bold text-primary">Total</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedIncomes.map((item) => {
              const currentTotal = 
                Number(localData[item.id]?.clt ?? item.clt) + 
                Number(localData[item.id]?.app ?? item.app) + 
                Number(localData[item.id]?.ifood ?? item.ifood) + 
                Number(localData[item.id]?.auxilio ?? item.auxilio);

              return (
                <TableRow key={item.id} className="group hover:bg-slate-50/50 transition-colors">
                  <TableCell className="font-medium bg-slate-50/30">{item.month}</TableCell>
                  
                  {['clt', 'app', 'ifood', 'auxilio'].map((field) => (
                    <TableCell key={field}>
                      <Input 
                        type="number" 
                        className={clsx(
                          "h-8 w-24 md:w-full bg-transparent border-transparent hover:border-border focus:bg-white transition-all text-right",
                          field === 'ifood' || field === 'auxilio' ? "text-muted-foreground" : "font-medium"
                        )}
                        value={localData[item.id]?.[field] ?? (item as any)[field]}
                        onChange={(e) => handleInputChange(item.id, field, e.target.value)}
                        onBlur={() => handleBlur(item.id, field, (item as any)[field])}
                      />
                    </TableCell>
                  ))}
                  
                  <TableCell className="text-right font-bold text-emerald-600 bg-emerald-50/30">
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(currentTotal)}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
